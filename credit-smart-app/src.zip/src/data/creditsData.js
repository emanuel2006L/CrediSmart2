const creditsData = [
  {
    id: 1,
    name: "Credito libre inversion",
    icon: "🏦",
    description: "Crédito para cubrir cualquier necesidad personal: viajes, mejoras en el hogar, pago de deudas o compra de tecnología.",
    interestEA: 22,     // % E.A.
    minAmount: 2000000,
    maxAmount: 120000000,
    maxTermMonths: 60
  },
  {
    id: 2,
    name: "Credito vehiculo",
    icon: "🚗",
    description: "Financiación para la compra de vehículos nuevos o usados.",
    interestEA: 17,
    minAmount: 15000000,
    maxAmount: 250000000,
    maxTermMonths: 84
  },
  {
    id: 3,
    name: "Credito de vivienda",
    icon: "🏠",
    description: "Crédito hipotecario para la compra de vivienda o construcción.",
    interestEA: 11,
    minAmount: 150000000,
    maxAmount: 800000000,
    maxTermMonths: 240 // 20 años
  },
  {
    id: 4,
    name: "Credito empresarial",
    icon: "🏭",
    description: "Financiación para capital de trabajo, compra de maquinaria o expansión.",
    interestEA: 19,
    minAmount: 20000000,
    maxAmount: 1000000000,
    maxTermMonths: 120
  },
  {
    id: 5,
    name: "Credito educativo",
    icon: "📚",
    description: "Financiación para estudios técnicos, universitarios o de posgrado.",
    interestEA: 14,
    minAmount: 1000000,
    maxAmount: 80000000,
    maxTermMonths: 96
  },
  {
    id: 6,
    name: "Credito salvavidas",
    icon: "🛟",
    description: "Crédito rápido para emergencias médicas o imprevistos personales.",
    interestEA: 24,
    minAmount: 500000,
    maxAmount: 10000000,
    maxTermMonths: 24
  }
];

export default creditsData;